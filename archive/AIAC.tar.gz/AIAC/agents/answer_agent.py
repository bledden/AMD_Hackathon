#!/usr/bin/env python3
"""
Tournament Answer Agent
Answers MCQ questions using TIES-merged ensemble (<6s requirement)
"""

import json
import logging
import time
import torch
from pathlib import Path
from unsloth import FastLanguageModel
from peft import PeftModel

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# Global model (loaded once at module import)
model = None
tokenizer = None
MODEL_LOADED = False

def load_model_once():
    """Load model once at startup"""
    global model, tokenizer, MODEL_LOADED

    if MODEL_LOADED:
        return

    logging.info("Loading Qwen2.5-72B + TIES-merged adapter...")
    start = time.time()

    model_obj, tokenizer_obj = FastLanguageModel.from_pretrained(
        model_name="Qwen/Qwen2.5-72B-Instruct",
        max_seq_length=2048,
        dtype=None,
        load_in_4bit=True,
    )

    model_obj = PeftModel.from_pretrained(
        model_obj,
        "/workspace/models/ties_merged_ensemble_r128"
    )

    FastLanguageModel.for_inference(model_obj)

    model = model_obj
    tokenizer = tokenizer_obj
    MODEL_LOADED = True

    elapsed = time.time() - start
    logging.info(f"Model loaded in {elapsed:.1f}s")

def answer_question(question_data):
    """
    Answer a multiple choice question

    Args:
        question_data: {
            "question": str,
            "choices": {"A": str, "B": str, "C": str, "D": str}
        }

    Returns:
        str: Answer letter (A, B, C, or D)
    """
    # Ensure model is loaded
    if not MODEL_LOADED:
        load_model_once()

    question = question_data['question']
    choices = question_data['choices']

    # Format prompt
    choices_text = "\n".join([f"{k}. {v}" for k, v in sorted(choices.items())])

    prompt = f"""<|im_start|>system
You are a highly knowledgeable assistant that answers multiple choice questions accurately.
Think carefully and select the best answer.<|im_end|>
<|im_start|>user
Question: {question}

Choices:
{choices_text}

Select the correct answer (A, B, C, or D):<|im_end|>
<|im_start|>assistant
The correct answer is """

    # Generate with low temperature for accuracy
    inputs = tokenizer([prompt], return_tensors="pt").to("cuda")

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=32,
            temperature=0.1,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )

    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    response = response.replace(prompt, "").strip()

    # Extract answer letter
    answer = extract_answer(response)
    return answer

def extract_answer(response):
    """Extract answer letter (A, B, C, or D) from model response"""
    response_upper = response.upper().strip()

    # Strategy 1: First letter if it's A, B, C, or D
    if response_upper and response_upper[0] in ['A', 'B', 'C', 'D']:
        return response_upper[0]

    # Strategy 2: Look for explicit patterns
    for pattern in ["ANSWER IS", "CORRECT ANSWER IS", "SELECT", "CHOOSE"]:
        if pattern in response_upper:
            after_pattern = response_upper.split(pattern)[1].strip()
            for letter in ['A', 'B', 'C', 'D']:
                if letter in after_pattern[:10]:
                    return letter

    # Strategy 3: Find first occurrence of valid letter
    for letter in ['A', 'B', 'C', 'D']:
        if letter in response_upper:
            return letter

    # Default fallback
    logging.warning(f"Could not extract answer from: {response}")
    return "A"

def main():
    """
    Main entry point for tournament
    Called by: python -m agents.answer_agent

    Input: Reads questions from outputs/questions.json or stdin
    Output: Writes answers to outputs/answers.json
    """
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    logging.info("A-Agent starting...")

    # Load model
    load_model_once()

    # Read questions (check both file and stdin)
    questions = []

    # Try reading from outputs/questions.json
    question_file = Path("/workspace/AIAC/outputs/questions.json")
    if question_file.exists():
        with open(question_file) as f:
            questions_data = json.load(f)
            if isinstance(questions_data, list):
                questions = questions_data
            else:
                questions = [questions_data]

    # If no file, try stdin
    if not questions:
        try:
            stdin_data = sys.stdin.read().strip()
            if stdin_data:
                questions_data = json.load(stdin_data)
                if isinstance(questions_data, list):
                    questions = questions_data
                else:
                    questions = [questions_data]
        except:
            pass

    if not questions:
        logging.error("No questions found!")
        return

    logging.info(f"Processing {len(questions)} question(s)...")

    # Answer each question
    answers = []
    for i, q in enumerate(questions, 1):
        start = time.time()

        answer = answer_question(q)
        elapsed = time.time() - start

        answers.append({
            "question_id": q.get('id', i),
            "answer": answer,
            "answer_time": elapsed
        })

        logging.info(f"   Q{i}: {answer} ({elapsed:.2f}s)")

    # Save to outputs/answers.json
    output_dir = Path("/workspace/AIAC/outputs")
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / "answers.json"
    with open(output_file, 'w') as f:
        json.dump(answers, f, indent=2)

    logging.info(f"✅ {len(answers)} answer(s) saved to {output_file}")

    # Summary stats
    avg_time = sum(a['answer_time'] for a in answers) / len(answers)
    max_time = max(a['answer_time'] for a in answers)

    logging.info(f"   Average time: {avg_time:.2f}s")
    logging.info(f"   Max time: {max_time:.2f}s")

    if max_time > 6.0:
        logging.warning(f"⚠️  Some answers exceeded 6s limit!")

if __name__ == "__main__":
    main()
